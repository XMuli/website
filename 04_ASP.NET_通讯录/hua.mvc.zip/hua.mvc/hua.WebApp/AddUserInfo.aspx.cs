﻿using hua.mvc.dao;
using hua.mvc.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace hua.WebApp
{
    public partial class AddUserInfo : System.Web.UI.Page
    {
        public string msg { set; get; }
        protected void Page_Load(object sender, EventArgs e)
        {
            if(this.IsPostBack)
            {
                string username = Request.Form["name"];
                string userpass = Request.Form["pass"];
                string usereamil = Request.Form["email"];

                

                

                UserInfoDao userInfoDao = new UserInfoDao();
                bool isOk = userInfoDao.check(username);

                if(isOk)   //没有重复，可以注册该账号
                {
                    #region  批量注册用户代码
                    for (int i = 1; i <= 10; i++)  //批量注册
                    {
                        string temp1 = "";
                        string temp2 = "";
                        string temp3 = "";
                        temp1 = username;
                        temp2 = userpass;
                        temp3 = usereamil;

                        temp1 += i;
                        temp2 += i;
                        temp3 += i;

                        if (userInfoDao.InsertUserInfo(temp1, temp2, temp3))
                        {
                            msg = "OJBK, 你已经注册成功了";
                        }
                        else
                        {
                            msg = "My Gril , 你注册失败了，再试一次吧";
                        }
                    }
                    #endregion


                }
                else  //不可注册这个用户名
                {
                    msg = "该用户名已经存在，请从新想一个，喵~";
                }



            }
        }
    }
}