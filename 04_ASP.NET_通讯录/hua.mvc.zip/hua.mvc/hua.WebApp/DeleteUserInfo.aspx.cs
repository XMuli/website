﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using hua.mvc.dao;
using hua.mvc.models;

namespace hua.WebApp
{
    public partial class DeleteUserInfo : System.Web.UI.Page
    {
        public string msg { set; get; }

        protected void Page_Load(object sender, EventArgs e)
        {
            int id = int.Parse(Request.QueryString["id2"]);  //链接的get提交， 隐藏获取
            int page = int.Parse(Request.QueryString["page2"]);

            if (!this.IsPostBack)
            {
                UserInfoDao userInfoDao = new UserInfoDao();

                if(userInfoDao.DeleteUserInfo(id))
                {
                    Response.Write(" <script>alert( '删除个人数据成功~' )</script> ");
                    Response.Redirect("/PagingDisplay.aspx?n=" + page);
                }
                else
                {
                    Response.Write(" <script>alert( '修改个人数据失败~' )</script> ");
                    Response.Redirect("/UserinfoList.aspx");
                }

                
            }
        }
    }
}