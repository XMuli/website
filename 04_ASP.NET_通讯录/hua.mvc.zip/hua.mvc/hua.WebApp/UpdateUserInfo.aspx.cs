﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using hua.mvc.dao;
using hua.mvc.models;

namespace hua.WebApp
{
    public partial class UpdateUserInfo : System.Web.UI.Page
    {
        public string msg { set; get; }
        static int temp_id = 0;
        protected void Page_Load(object sender, EventArgs e)
        {
            int page3 = int.Parse(Request.QueryString["page"]);
            if (!this.IsPostBack)  //get提交
            {
                //*************************************
                //网页发送过来的数据全部是以 字符串的形式发送
                //*************************************
                int id = int.Parse(Request.QueryString["id"]);  //链接的get提交， 隐藏获取
                

                temp_id = id;
                //updata_id.text =    //传入id TODO：
                //int id = int.Parse(Request.Form["id"]);  
            }
            else
            {
                string name = Request.Form["name"];  //手动输入获取
                string pass = Request.Form["pass"];
                string email = Request.Form["email"];

                UserInfoDao userInfoDao = new UserInfoDao();

                if (userInfoDao.UpdatatUserInfo(temp_id, name, pass, email))
                {
                    Response.Write(" <script>alert( '修改个人数据OJBK~' )</script> ");
                    Response.Redirect("/PagingDisplay.aspx?n="+page3);
                }
                else
                {
                    Response.Write(" <script>alert( '修改个人数据失败~' )</script> ");
                }
            }
            
        }
    }
}