﻿using hua.mvc.dao;
using hua.mvc.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace hua.WebApp
{
    public partial class UserinfoList : System.Web.UI.Page
    {

        public List<UserInfo> userInfoList { set; get; }
        public StringBuilder tbody { set; get; }


        protected void Page_Load(object sender, EventArgs e)
        {
            // 注意:get请求过来的还是post请求过来true的
            //如果是为响应客户端回发而加载该页，则为 true；否则为 false。 
            if (!this.IsPostBack)
            {
                UserInfoDao userInfoDao = new UserInfoDao();
                userInfoList = userInfoDao.findAll();

                //旧的方式来进行替换
                //tbody = new StringBuilder();
                //foreach (UserInfo userInfo in userInfoList)
                //{
                //     //<% -- //UserInfo u_id u_name  u_password u_regedittime  u_email--%>
                //    tbody.AppendFormat("<tr><td>{0}</td><td>{1}</td><td>{2}</td><td>{3}</td><td>{4}</td></tr>",
                //        userInfo.u_id, userInfo.u_name,userInfo.u_password, userInfo.u_regedittime.ToShortDateString(), userInfo.u_email);
                //}
            }
            else
            {
                //可以用于之后去处理post请求
            }

        }

    }
}