﻿using softeem.test3.dao;
using softeem.test3.models;
using softeem.test3.util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace softeem.test3.WebApp.Session_ValidateCode
{
    public partial class Login : System.Web.UI.Page
    {
        public string ErrorMsg { get; set; }
        public string userName { set; get; }
        public string userPwd { set; get; }

        protected void Page_Load(object sender, EventArgs e)
        {
            //服务端也要校验.(与客户端校验自己完成)
            //1.判断验证码是否正确
            if (IsPostBack)//表示用户单击了登录按钮
            {
                userName = Request.Form["txtClientID"];
                userPwd = Request.Form["txtPassword"];
           
                if (CheckValidateCode())
                {
                    UserLoginIn();
                }
                else
                {
                    ErrorMsg = "验证码错误!!";
                }
            }
            else//表示GET请求
            {
                CheckCookieInfo();//校验Cookie信息
            }

        }
        protected void CheckCookieInfo()
        {
            //判断Cookie中是否有值
            if (Request.Cookies["cp1"] != null && Request.Cookies["cp2"] != null)
            {
                string userName = Request.Cookies["cp1"].Value;
                string userPwd = Request.Cookies["cp2"].Value;
                //判断Cookie中存储的用户名是否正确
              
                UserInfoDao dao = new UserInfoDao();
                UserInfo userInfo= dao.findUserByName(userName);
                if (userInfo != null)
                {
                    //判断密码是否正确.
                    if (userPwd == MyMd5.GetMd5String(userInfo.userpass))
                    {
                        Session["userInfo"] = userInfo;
                        Response.Redirect("AdminIndex.aspx");
                    }
                }
                Response.Cookies["cp1"].Expires = DateTime.Now.AddDays(-1);
                Response.Cookies["cp2"].Expires = DateTime.Now.AddDays(-1);
            }
        }
        protected void UserLoginIn()
        {
            
            UserInfo userInfo = null;
            UserInfoDao dao = new UserInfoDao();
            userInfo = dao.login(userName, userPwd);
            if (userInfo!=null)
            {
                Session["userInfo"] = userInfo;//用户名密码判断dnrg成功后一定要将userInfo对象保存到session中
                string x = Request.Form["CheckMe"];
                //判断用户是否选择了记住我
                if (!string.IsNullOrEmpty(Request.Form["CheckMe"]))
                {
                    HttpCookie cookie1 = new HttpCookie("cp1", userName);
                    HttpCookie cookie2 = new HttpCookie("cp2", MyMd5.GetMd5String(userPwd));
                    cookie1.Expires = DateTime.Now.AddDays(3);
                    cookie2.Expires = DateTime.Now.AddDays(3);
                    Response.Cookies.Add(cookie1);
                    Response.Cookies.Add(cookie2);
                }
                Response.Redirect("AdminIndex.aspx");
            }
            else
            {
                ErrorMsg = "用户名密码错误";
            }
        }
        /// <summary>
        /// 对验证码进行校验
        /// </summary>
        /// <returns></returns>
        protected bool CheckValidateCode()
        {
            bool isSuccess = false;
            if (Session["code"] != null)
            {
                string sysCode = Session["code"].ToString();
                string txtCode = Request.Form["txtCode"];
                //StringComparison.InvariantCultureIgnoreCase比较时忽略大小写
                if (sysCode.Equals(txtCode, StringComparison.InvariantCultureIgnoreCase))
                {
                    Session["code"] = null;//成功后把session中的验证码清除掉
                    // Session.Remove("code");
                    isSuccess = true;
                }
            }
            return isSuccess;

        }
    }

}