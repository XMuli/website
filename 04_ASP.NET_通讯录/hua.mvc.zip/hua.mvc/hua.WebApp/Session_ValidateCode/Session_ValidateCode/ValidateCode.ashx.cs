﻿using softeem.test3.util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace softeem.test3.WebApp.Session_ValidateCode
{
    /// <summary>
    /// ValidateCode 的摘要说明
    /// </summary>
    public class ValidateCode : IHttpHandler, System.Web.SessionState.IRequiresSessionState
    {

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/plain";
            MyValidate validateCode = new MyValidate();
            
            string code = validateCode.CreateValidateCode(4);
            context.Session["code"] = code;//保存到session中
            validateCode.CreateValidateGraphic(code, context);
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}