﻿using softeem.test3.dao;
using softeem.test3.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace softeem.test3.WebApp.Session_ValidateCode
{
    public partial class SessionDemo1 : System.Web.UI.Page
    {
        public string msg { set; get; }
        protected void Page_Load(object sender, EventArgs e)
        {
            //session会话作用域 
            if (this.IsPostBack)
            {
                string name = Request.Form["name"];
                string pass = Request.Form["pass"];

                UserInfoDao dao = new UserInfoDao();
                UserInfo user = dao.login(name,pass);
                if(user != null){
                    Session["myuser"] = user;

                    //Session.Clear();//清除此Session中的所有数据
                    //Session["sessionname"] = null;
                    //Session.Remove("sessionname");
                    Session.Timeout = 20; //设置一分就超时,默认20分钟
                    Response.Redirect("/Session_ValidateCode/SessionDemo2.aspx");
                }else{
                    msg = "用户名或者密码输入错误,请重输入!";
                }
            }
            else
            {
                if (Request.QueryString["msg"]!=null) {
                    if (Request.QueryString["msg"] == "1")
                    {
                        msg = "请先登录,不登录无法访问此资源";
                    }
              
                }

            }
            

        }
    }
}