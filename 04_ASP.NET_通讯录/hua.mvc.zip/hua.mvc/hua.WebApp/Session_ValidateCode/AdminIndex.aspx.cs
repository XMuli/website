﻿using hua.mvc.models;
using hua.mvc.dao;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace softeem.test3.WebApp.Session_ValidateCode
{
    public partial class AdminIndex : System.Web.UI.Page
    {
        public UserInfo userInfo { get; set; }
        protected void Page_Load(object sender, EventArgs e)
        {
              if (Session["userInfo"] == null)
              {
                   Response.Redirect("Login.aspx");
              }
              else
             {
                userInfo = (UserInfo)Session["userInfo"];
             }
        }
    }
}