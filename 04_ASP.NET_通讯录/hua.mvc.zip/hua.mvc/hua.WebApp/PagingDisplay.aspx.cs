﻿using hua.mvc.dao;
using hua.mvc.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace hua.WebApp
{
    public partial class PagingDisplay : System.Web.UI.Page
    {

        public int nPage { set; get; }  //传递进来的页数（参数）
        public int maxPage { set; get; }  //总共有的页数
        public List<UserInfo> userInfoList { set; get; }
        public StringBuilder tbody { set; get; }


        //===============================================
        //给html页面进行传值保持它的点击下一页不改变
        public string username { set; get; }
        public string useremail { set; get; }
        public string userstarttime { set; get; }
        public string userendtime { set; get; }
        //===============================================


        protected void Page_Load(object sender, EventArgs e)
        {
            username = Request.QueryString["username"];
            useremail = Request.QueryString["useremail"];
            userstarttime = Request.QueryString["userstarttime"];
            userendtime = Request.QueryString["userendtime"];

            /*此处的逻辑， 注意第一次点击页面跳转 和 后面在本html 点击上一页下一下，让nPage的值有所改变*/
            if (!this.IsPostBack)
            {
                //虽然是表单提交，但是提交的按钮是button，不是submit， 所以为get提交   ==>数据写到了 <input type="text"==>button通过JS代码提交==>get方式提交==>该应用处理程序进行get方式获取
               

                int n_temp = 0;  //临时变量，记录改变nPage的数值
                if (!int.TryParse(Request.QueryString["n"], out n_temp))  //传递进来的数据为非法的
                {   //第一遍进来，因为没有传递参数进来，所以会变成n_temp =1 
                    n_temp = 1;  //强制显示，只会显示第一页

                }

                UserInfoDao userInfoDao = new UserInfoDao();
                nPage = n_temp;  //第一次在这里显赋值给 nPage = 1；
                userInfoList = userInfoDao.pagingDisplay(nPage, username, useremail, userstarttime, userendtime);
                maxPage = userInfoDao.maxPage(nPage, username, useremail, userstarttime, userendtime);


            }
            else
            {

                string page_temp = Request.Form["PageInPut"].ToString();
                int page_out = 0;
                if (!int.TryParse(page_temp, out page_out))  //传递进来的数据为非法的
                {   //第一遍进来，因为没有传递参数进来，所以会变成n_temp =1 
                    page_out = 1;  //强制显示，只会显示第一页

                }

                UserInfoDao userInfoDao = new UserInfoDao();
                nPage = page_out;  //第一次在这里显赋值给 nPage = 1；
                userInfoList = userInfoDao.pagingDisplay(nPage, username, useremail, userstarttime, userendtime);
                maxPage = userInfoDao.maxPage(nPage, username, useremail, userstarttime, userendtime);
                //可以用于之后去处理post请求
            }


        }
    }
}