﻿using hua.mvc.dao;
using hua.mvc.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace hua.WebApp
{
    public partial class Login : System.Web.UI.Page
    {
        public string msg { set; get; }  //在这里定义msg，上一级的Login.aspx（相当于Login.html）里面的msg 才可以使使用

        protected void Page_Load(object sender, EventArgs e)
        {
            if(this.IsPostBack)
            {
                string username = Request.Form["username"];
                string userpass = Request.Form["userpass"];

                UserInfoDao userInfoDao = new UserInfoDao();

                UserInfo userInfo = userInfoDao.login(username, userpass);

                if (userInfo == null)
                {
                    msg = "您的用户名或密码输入错误 ,请重新输入 ";
                }
                else
                {
                    Response.Redirect("/UserinfoList.aspx");
                }
            }
           

        }
    }
}