﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using hua.mvc.models;
using hua.mvc.dao;


namespace hua.WebApp
{
    /// <summary>
    /// Login2 的摘要说明
    /// </summary>
    public class Login2 : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/plain";
            //context.Response.Write("Hello World");

            string username = context.Request.Form["username"];
            string userpass = context.Request.Form["userpass"];

            UserInfoDao userInfoDao = new UserInfoDao();
            UserInfo userInfo = userInfoDao.login(username, userpass);

            if (userInfo == null)
            {
                context.Response.Write("登录账号或者密码错误!");
            }
            else
            {
                context.Response.Redirect("/Test/success.html");
            }
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}