﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using hua.mvc.models;  //左边的引入不仅需要导入， 还需要手动添加
using System.Data.SqlClient;
using System.Runtime.Remoting.Contexts;

namespace hua.mvc.dao
{
    public class UserInfoDao
    {
        public List<UserInfo> findUserByName(string name)
        {
            name = "";
            return null;
        }



        //********************查询函数********************
        //相当于使用模板，将里面的数值全部都取出来
        public List<UserInfo> findAll()
        {
            string sql = "select * from UserInfo";
            //CommandType.Text:sql语句
            DataTable dt = SqlHelper.GetTable(sql, CommandType.Text, null);
            //创建一个List集合对象用于保存从数据库查询出来的结果集
            //泛型:设置list集合的泛型为UserInfo对象 ..所以List集合中只能存储UserInfo对象 而不能保存其它类型
            List<UserInfo> userInfoList = new List<UserInfo>();

            foreach (DataRow row in dt.Rows)
            {
                UserInfo userInfo = new UserInfo();//数据库表中有多少条数据我们创建多少个对象 第一条数据 对应 一个对象,一个对象就好比一个实现生活中的用户

                userInfo.u_id = Int32.Parse(row["u_id"].ToString());  //强制转换int
                userInfo.u_name = row["u_name"].ToString();
                userInfo.u_password = row["u_password"].ToString();
                userInfo.u_regedittime = Convert.ToDateTime(row["u_regedittime"]);  //强制转换DateTime
                userInfo.u_email = row["u_email"].ToString();

                userInfoList.Add(userInfo);//再将创建出来的userInfo对象一一保存到userInfoList集合中
            }

            return userInfoList;
        }


        //********************登录函数********************
        //返回结果如果是非对象.就证明用户名和密码输入错误.如果是非对象就证明输入是正确的
        public UserInfo login(string username, string userpass)
        {

            UserInfo userInfo = null;
            string sql = "select * from UserInfo where u_name = @username and u_password = @userpass";

            SqlParameter[] pars = { new SqlParameter("@username",SqlDbType.NVarChar),
                                    new SqlParameter("@userpass",SqlDbType.NVarChar)
                                   };
            pars[0].Value = username;
            pars[1].Value = userpass;
            DataTable dt = SqlHelper.GetTable(sql, CommandType.Text, pars);

            if (dt.Rows.Count > 0)
            {
                //数据表： UserInfo u_id u_name  u_password u_regedittime  u_email
                DataRow row = dt.Rows[0];
                userInfo = new UserInfo();//实例化 ,并且将此条数据保存到userinfo对象中
                userInfo.u_id = Int32.Parse(row["u_id"].ToString());  //强制转换int
                userInfo.u_name = row["u_name"].ToString();
                userInfo.u_password = row["u_password"].ToString();
                userInfo.u_regedittime = Convert.ToDateTime(row["u_regedittime"]);  //强制转换DateTime
                userInfo.u_email = row["u_email"].ToString();
                return userInfo;
            }
            else
            {
                return userInfo;
            }
        }


        //********************注册，校验是否已经存在函数********************
        public bool check(string username)
        {
            string sql = "select count(*) i from UserInfo where u_name = @username";

            SqlParameter[] pars = { new SqlParameter("@username", SqlDbType.NVarChar) };
            pars[0].Value = username;
            DataTable dt = SqlHelper.GetTable(sql, CommandType.Text, pars);
            DataRow dataRow = dt.Rows[0];

            int nCount = int.Parse(dataRow["i"].ToString());
            if (nCount == 0)  //没有重复，可以注册
            {
                return true;
            }
            else  //不可以注册
            {
                return false;
            }
        }


        //********************插入新用户(判断是否已经存在)函数********************
        public bool InsertUserInfo(string name, string pass, string eamil)
        {
            string sql = "insert into UserInfo values(@name, @pass, GetDate(), @eamil)";
            SqlParameter[] pars = { new SqlParameter("@name", SqlDbType.NVarChar),
                                    new SqlParameter("@pass", SqlDbType.NVarChar),
                                    new SqlParameter("@eamil", SqlDbType.NVarChar)};
            pars[0].Value = name;
            pars[1].Value = pass;
            pars[2].Value = eamil;

            int i = SqlHelper.ExecuteNonQuery(sql, CommandType.Text, pars); //返回增删改的影响结果行数
            return i >= 1 ? true : false;

        }

        //********************修改用户信息(根据u_id来判断，是否存在这个数据)函数********************
        public bool UpdatatUserInfo(int id, string name, string pass, string eamil)
        {
            //i 是count（*） 的别名
            string sql = "select count(*) i from userinfo where u_id = @id";
            SqlParameter[] pars = { new SqlParameter("@id", SqlDbType.Int) };

            pars[0].Value = id;
            DataTable dt = SqlHelper.GetTable(sql, CommandType.Text, pars);
            DataRow dataRow = dt.Rows[0];  //获取sql 语句运行返回的结果， 取第一行的（所有）数据
            int nCount = int.Parse(dataRow["i"].ToString());  //i 为上面sql 里面的别名   从第一行里面的所有数据取出列名为"i"的 那一个数据

            if(nCount == 1)
            {
                string sql1 = "update userinfo set u_name = @name, u_password = @pass, u_email = @eamil where u_id = @id";
                SqlParameter[] pars1 = {  new SqlParameter("@id", SqlDbType.Int),
                                          new SqlParameter("@name", SqlDbType.NVarChar),
                                          new SqlParameter("@pass", SqlDbType.NVarChar),
                                          new SqlParameter("@eamil", SqlDbType.NVarChar)};
                pars1[0].Value = id;
                pars1[1].Value = name;
                pars1[2].Value = pass;
                pars1[3].Value = eamil;
                int i = SqlHelper.ExecuteNonQuery(sql1, CommandType.Text, pars1); //返回增删改的影响结果行数
                return i == 1 ? true : false;
            }
            else
            {
                //this.Page.RegisterStartupScript(" ", "<script>alert(' 数据库相关表里面不存在该u_id的数据 '); </script> ");
                //Response.Write(" <script>alert( ' 数据库相关表里面不存在该u_id的数据' )</script> ");
                return false;
            }
            
        }


        //********************删除用户信息(根据u_id来判断)函数********************
        public bool DeleteUserInfo(int id)
        {
            string sql1 = "delete from userinfo where u_id = @id";
            SqlParameter[] pars1 = {  new SqlParameter("@id", SqlDbType.Int)};
            pars1[0].Value = id;
            int i = SqlHelper.ExecuteNonQuery(sql1, CommandType.Text, pars1); //返回增删改的影响结果行数
            return i == 1 ? true : false;
        }

        //***************************求最大页方法***************************************
        public int pageCount = 10;  //全局变量 ,一页显示的数量
        public int maxPage(int pageNumber, string name, string email, string startime, string endtime)
        {
            string sql = "select count(*) from userinfo where 1 = 1";

            if (name != null && !name.Equals(""))
            {
                sql += "and u_name like '%" + name + "%'";   //eg： 作为sql语句的一部分 and u_name like '%张三%'    
            }

            if (email != null && !email.Equals(""))
            {
                sql += "and u_email like '%" + email + "%'";
            }

            if (startime != null && !startime.Equals(""))
            {
                sql += "and u_regedittime >= '" + startime + "'";
            }

            if (endtime != null && !endtime.Equals(""))
            {
                sql += "and u_regedittime <= '" + endtime + "'";
            }

            object obj = SqlHelper.ExecuteScalar(sql, CommandType.Text, null);

            int tablecount = Int32.Parse(obj.ToString());
            if (tablecount % pageCount == 0)
            {
                tablecount = tablecount / pageCount;
            }
            else
            {
                tablecount = tablecount / pageCount + 1;
            }
            return tablecount;

        }


        //********************分页显示（传入页码进来）函数********************
        public List<UserInfo> pagingDisplay(int pageNumber, string name, string email, string startime, string endtime)
        {
            int PageDisplayNumber = 10;  //一页显示的数据条数

            int starNumber = (pageNumber - 1) * PageDisplayNumber;  //显示的数据
            int endNumber = starNumber + PageDisplayNumber;

            //==================================================================
            //多表 多条件查询 【嵌套查询 sql 语句进行拼接 】
            //string sql = "select * from (select * , row_number() over(order by u_id desc) r from userinfo) temp where r >= @start_sql and r <= @end_sql; ";
            string sql = "select * from (select * , row_number() over(order by u_id desc) r from userinfo temp where 1 = 1";

            if(name != null && !name.Equals(""))
            {
                sql += "and u_name like '%" + name + "%'";   //eg： 作为sql语句的一部分 and u_name like '%张三%'    
            }

            if (email != null && !email.Equals(""))
            {
                sql += "and u_email like '%" + email + "%'";   
            }

            if (startime != null && !startime.Equals(""))
            {
                sql += "and u_regedittime >= '" + startime + "'";     
            }

            if (endtime != null && !endtime.Equals(""))
            {
                sql += "and u_regedittime <= '" + endtime + "'";   
            }

            string endsql = ") temp where r >= @start_sql and r <= @end_sql;";
            sql += endsql;
            //sql 语句的拼接完毕
            //==================================================================

            SqlParameter[] pars = {new SqlParameter("@start_sql", SqlDbType.Int),
                                   new SqlParameter("@end_sql", SqlDbType.Int)
                                  };

            pars[0].Value = starNumber;
            pars[1].Value = endNumber;

            //执行上面的GSql语句， 只显示10行的哪一个
            DataTable dt = SqlHelper.GetTable(sql, CommandType.Text, pars);
            List<UserInfo> userInfoList = new List<UserInfo>();
            foreach (DataRow row in dt.Rows)
            {
                UserInfo userInfo = new UserInfo();//数据库表中有多少条数据我们创建多少个对象 第一条数据 对应 一个对象,一个对象就好比一个实现生活中的用户

                userInfo.u_id = int.Parse(row["u_id"].ToString());  //强制转换int
                userInfo.u_name = row["u_name"].ToString();
                userInfo.u_password = row["u_password"].ToString();
                userInfo.u_regedittime = Convert.ToDateTime(row["u_regedittime"]);  //强制转换DateTime
                userInfo.u_email = row["u_email"].ToString();

                userInfoList.Add(userInfo);//再将创建出来的userInfo对象一一保存到userInfoList集合中
            }
            return userInfoList;
        }


    }
}
