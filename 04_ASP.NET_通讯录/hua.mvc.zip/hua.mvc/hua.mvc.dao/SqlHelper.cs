﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//************************************************************************************************
//DAO(Data Access Object)是一个数据访问接口，数据访问：顾名思义就是与数据库打交道。夹在业务逻辑与数据库资源中间。
//************************************************************************************************


namespace hua.mvc.dao
{
    public class SqlHelper  //要设置为public类型
    {

        //???
        private readonly static string connStr = "server=10.83.48.8;uid=sa;pwd=Aq123456;database=huahua";
        //private readonly static string connStr = "server=118.24.62.241;uid=hua;pwd=Aq123456;database=huahua";

        /*
         * 此方法专门针对查询操作
         * sql:查询语句
         * type:表示你想使用什么方式出来查询.1.sql语句 2.存储过程 
         * pars:参数数组
         */
        public static DataTable GetTable(string sql, CommandType type, params SqlParameter[] pars)
        {
            DataTable dt = null;  //定义数据表哦
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                using (SqlDataAdapter adper = new SqlDataAdapter(sql, conn))
                {
                    adper.SelectCommand.CommandType = type;//设置什么方式进行查询(sql语句,存储过程)
                    if (pars != null)
                    {
                        adper.SelectCommand.Parameters.AddRange(pars);
                    }

                    dt = new DataTable();
                    adper.Fill(dt);
                }
            }
            return dt;
        }


        /*
         * 此方法专门针对删除 , 修改 , 添加操作
         * sql:查询语句
         * type:表示你想使用什么方式出来查询.1.sql语句 2.存储过程 
         * pars:参数数组
         */
        public static int ExecuteNonQuery(string sql, CommandType type, params SqlParameter[] pars)
        {
            int i = 0;
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    cmd.CommandType = type; ;//设置什么方式进行操作(sql语句,存储过程)
                    if (pars != null)
                    {
                        cmd.Parameters.AddRange(pars);
                    }
                    conn.Open();
                    i = cmd.ExecuteNonQuery();   //执行所影响的行数

                }
            }
            return i;
        }

        //这一段是干什么是用的？？？暂时没有卵用  以后会将这一段的使用
        public static object ExecuteScalar(string sql, CommandType type, params SqlParameter[] pars)
        {
            object obj = null;
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    cmd.CommandType = type; ;//设置什么方式进行操作(sql语句,存储过程)
                    if (pars != null)
                    {
                        cmd.Parameters.AddRange(pars);
                    }
                    conn.Open();
                    obj = cmd.ExecuteScalar();  //返回所有结果集中于第一行的第一列，作为一个对象返回出来
                }
            }
            return obj;
        }
    }
}
