﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hua.mvc.models
{
    public class Image
    {
        public int i_id { set; get; }
        public string i_path { set; get; }
        public string i_Info { set; get; }
        public int i_user_id { set; get; }

    }
}
