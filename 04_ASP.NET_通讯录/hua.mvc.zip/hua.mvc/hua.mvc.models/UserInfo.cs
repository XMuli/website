﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hua.mvc.models
{
   public class UserInfo
    {
        public int u_id { set; get; }
        public string u_name { set; get; }
        public string u_password { set; get; }
        public DateTime u_regedittime { set; get; }
        public string u_email { set; get; }
    }
}

//UserInfo u_id u_name  u_password u_regedittime  u_email