﻿using hua_bbs.BLL;
using hua_bbs.DAL;
using hua_bbs.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication.admin
{
    public partial class Login : System.Web.UI.Page
    {
        public string error { set; get; }
        public UserDao userDao { set; get; }

        public string nickName;
        public string passWord;

        public string nickName1;
        public string passWord1;


        protected void Page_Load(object sender, EventArgs e)
        {
            HttpCookie cookie1 = null;
            HttpCookie cookie2 = null;

            if (this.IsPostBack)
            { 
                    #region 登陆的代码
                    nickName = Request.Form["user_nickName"];
                    passWord = Request.Form["user_password"];
                    string imageCode = Request.Form["imageCode"];

                    Session["Username_session"] = nickName;  //(给其他地方使用， 相当于全局变量)


                    if (Session["code"].ToString().Equals(imageCode))  //什么意思？   Session["code"]是在admin/ValidateCode.ashx.cs 里面定义的数据
                    {
                        UserService userService = new UserService();
                        List<User> user = userService.GetModelList("nickname='" + nickName + "' and password='" + passWord + "'");
                        if (user.Count > 0)
                        {
                            User u = user[0];
                            Session["user"] = u;

                        //*************************************************************************************\
                        //使用cookie
                        //判断用户是否选择了记住我
                        if (!string.IsNullOrEmpty(Request.Form["CheckMe"]))   //判断是否打钩记住了我？
                        {
                            //避免中文乱码，需要进行转码
                            cookie1 = new HttpCookie("cp1", Server.UrlEncode(nickName));  //创建cookie
                            cookie2 = new HttpCookie("cp2", Server.UrlEncode(passWord));
                            Response.Cookies.Add(cookie1);   //将cookie存入到浏览器
                            Response.Cookies.Add(cookie2);
                            cookie1.Expires = DateTime.Now.AddDays(7);  //设置过期时间
                            cookie2.Expires = DateTime.Now.AddDays(7);
                        }
                        //*************************************************************************************

                        Response.Redirect("/Index.aspx");
                        }
                        else
                        {
                            error = "您的用户名或者密码错误请重新输入!";
                        }
                    }
                    else
                    {
                        error = "您的验证码错误!";
                    }
                    #endregion
            }
            else
            {
                CheckCookieInfo();
            }
        }


        protected void CheckCookieInfo()
        {
            //判断Cookie中是否有值
            if (Request.Cookies["cp1"] != null && Request.Cookies["cp2"] != null)
            {
                nickName1 = Request.Cookies["cp1"].Value;
                passWord1 = Request.Cookies["cp2"].Value;


                Session["Username_session"] = nickName1;  //(给其他地方使用， 相当于全局变量)

                UserService userService = new UserService();
                List<User> user = userService.GetModelList("nickname='" + nickName1 + "' and password='" + passWord1 + "'");
                if (user.Count > 0)
                {
                    User u = user[0];
                    Session["user"] = u;

                    if (u.nickname == nickName1 && u.password == passWord1)
                    {
                        Response.Redirect("/Index.aspx");
                    }
                    else
                    {
                        Response.Cookies["cp1"].Expires = DateTime.Now.AddDays(-1);
                        Response.Cookies["cp2"].Expires = DateTime.Now.AddDays(-1);
                    }



                }
                else
                {
                    error = "您的用户名或者密码错误请重新输入!";
                }

            }
        }

    }
}