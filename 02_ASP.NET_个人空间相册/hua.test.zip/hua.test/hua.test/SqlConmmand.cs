﻿using System;
using System.Data.SqlClient;

namespace hua.test
{
    internal class SqlConmmand
    {
        private SqlConnection conn;
        private string sql;

        public SqlConmmand(string sql, SqlConnection conn)
        {
            this.sql = sql;
            this.conn = conn;
        }

        internal int ExecuteNonQuery()
        {
            throw new NotImplementedException();
        }
    }
}