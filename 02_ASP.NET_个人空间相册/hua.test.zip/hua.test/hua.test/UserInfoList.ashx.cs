﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;

namespace hua.test
{
    /// <summary>
    /// UserInfoList 的摘要说明
    /// </summary>
    public class UserInfoList : IHttpHandler
    {
        //申明一个数据库地址与数据库名
        private readonly static string connStr = "server=10.83.48.8; uid=sa; pwd=Aq123456; database=huahua";

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/html";     /*注意plain*/
            //context.Response.Write("Hello World");

            //得到数据库连接对象conn
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                string sql = "select * from dbo.Table_1";  //定义select语句

                //得到数据库适配器对象，需要传入sql语句+数据库连接对象
                using (SqlDataAdapter atper = new SqlDataAdapter(sql, conn))
                {
                    DataTable da = new DataTable();  //创建数据表单对象
                    atper.Fill(da);  //将数据库中查询到的结果集填充到da对象中去

                    int i = da.Rows.Count;  //查询到有几条数据

                    //context.Response.Write(i);

                    if(i > 0)
                    {
                        StringBuilder abuiler = new StringBuilder();

                        foreach(DataRow row in da.Rows)
                        {
                            //DeleteUserInfo.ashx? id = {0};    
                                                                                                                                 //*******此次会有一个坑*********
                            abuiler.AppendFormat("<tr><td>{0}</td><td>{1}</td><td>{2}</td><td>{3}</td><td>{4}</td><td><a href = \"javascript:mydel(\'{0}\')\">删除{0}</a></td><td><a href='UpdateUserInfo.ashx?id={0}&flag=1'>修改</a></td></tr>",
                                                 row["s_id"], row["s_passed"], row["s_name"], row["s_time"], row["s_email"]);
                        }

              
                        //得到UserInfoList.html的绝对路径 
                        string filePath = context.Request.MapPath("UserInfoList.html");
                        //得到index.html里面的文本内容 
                        string fileContext = File.ReadAllText(filePath);
                        //把文本里指的内容进行替换
                        fileContext = fileContext.Replace("$sdd", abuiler.ToString());
                        //将替换后的内容输出到客户端(浏览器)
                        context.Response.Write(fileContext);

                    }

                }
            }



        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}