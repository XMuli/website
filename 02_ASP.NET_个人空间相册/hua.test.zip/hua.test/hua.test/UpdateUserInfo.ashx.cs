﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;

namespace hua.test
{
    /// <summary>
    /// UpdateUserInfo 的摘要说明
    /// </summary>
    public class UpdateUserInfo : IHttpHandler
    {
        private readonly static string connStr = ConfigurationManager.ConnectionStrings["connStr"].ConnectionString;
        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/html";
            //context.Response.Write("Hello World");

                                         //先一定是点击链接的方式，get方式提交的，然后造成的QueryString接收数据
            string flag = context.Request.QueryString["flag"];  //后一个"flag" 是 UserInfoList.ashx里面传入的参数   前一个是在这个页面定义的
            //如果此flag变量为null就是需要进行修改操作,否则是需要进行查询操作        
            if (flag == null)  //（后进行）修改，是由==> 点击UpdateUserInfo.html里面按钮造成的
            {
                //修改用户信息
                string id = context.Request.Form["Update_html_id"];
                string name = context.Request.Form["Update_html_name"];
                string pwd = context.Request.Form["Update_html_passwed"];
                string email = context.Request.Form["Update_html_email"];
                int i = 0;
                using (SqlConnection conn = new SqlConnection(connStr))
                {                                        
                    //更新语句
                    string sql = "update dbo.Table_1 set s_name = @username , s_passed = @pwd , s_email = @email where s_id = @id";
                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        SqlParameter[] pars = {       // $htm_id
                                               new SqlParameter("@username",SqlDbType.NVarChar),
                                               new SqlParameter("@pwd",SqlDbType.NVarChar),
                                               new SqlParameter("@email",SqlDbType.NVarChar),
                                               new SqlParameter("@id",SqlDbType.NVarChar)
                                               };
                        pars[0].Value = name;
                        pars[1].Value = pwd;
                        pars[2].Value = email;
                        pars[3].Value = id;
                        cmd.Parameters.AddRange(pars);
                        conn.Open();
                        i = cmd.ExecuteNonQuery();

                    }
                }

                if (i > 0)
                {
                    context.Response.Redirect("UserInfoList.ashx");
                }
                else
                {
                    context.Response.Write("修改失败");
                }

            }
            else   //(按道理是先进行)查询，是由==> 点击链接UserInfoList.ashx里面的修改链接造成的
            {
                //查询用户信息
                string id = context.Request.QueryString["id"];   //UserInfoList.ashx里面修改链接的的id  那个里面传来的参数
                using (SqlConnection conn = new SqlConnection(connStr))
                {
                    //查询语句
                    string sql = "select * from dbo.Table_1 where s_id = @id";
                    using (SqlDataAdapter adapter = new SqlDataAdapter(sql, conn))
                    {
                        SqlParameter[] pars = { new SqlParameter("@id", SqlDbType.NVarChar) };
                        pars[0].Value = id;
                        adapter.SelectCommand.Parameters.AddRange(pars);
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        DataRow row = dt.Rows[0];

                        //得到UpdateUserInfo.html的绝对路径 
                        string filePath = context.Request.MapPath("UpdateUserInfo.html");
                        //得到UpdateUserInfo.html里面的文本内容 
                        string fileContext = File.ReadAllText(filePath);
                        //把文本里指的内容进行替换    $htm_name $htm_passwed $htm_email   //dbo.Table_1  s_email  s_id  s_passed  s_name  s_time   s_email
                        fileContext = fileContext.Replace("$htm_name", row["s_name"].ToString()).Replace("$htm_passwed", row["s_passed"].ToString()).Replace("$htm_email", row["s_email"].ToString()).Replace("$htm_id", row["s_id"].ToString());
                        //将替换后的内容输出到客户端(浏览器)
                        context.Response.Write(fileContext);
                    }
                }
             }

            


        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}