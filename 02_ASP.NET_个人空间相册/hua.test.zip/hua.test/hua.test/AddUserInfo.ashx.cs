﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;

//====================================================
//SqlCommand :在进行 删除or修改or插入 时使用此对象
//SqlDataAdapter :在进行 查询 时使用此对象
//====================================================


namespace hua.test
{
    /// <summary>
    /// AddUserInfo 的摘要说明
    /// </summary>
    public class AddUserInfo : IHttpHandler
    {
        private readonly static string connStr = "server=10.83.48.8; uid=sa; pwd=Aq123456; database=huahua";


        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/plain";
            // context.Response.Write("Hello World");


                
            //获取页面提交的上来的一行（3列, 实际一行一共有5列数据）数据
            string id = context.Request.Form["userid"];
            string pass = context.Request.Form["userpass"];
            string name = context.Request.Form["username"];
            string email = context.Request.Form["useremail"];

            int i = 0;


            using (SqlConnection conn = new SqlConnection(connStr))
            {
                string sql = "insert into dbo.Table_1 values(@id, @pass, @name, GetDate(), @email)";

                //得到数据库适配器对象，需要传入sql语句+数据库连接对象
                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {

                    //-----------------------------------------------------------------
                    //申明一个参数数组.并且定义好,每个参数的类型
                    SqlParameter[] pars =
                    {
                        new SqlParameter("@id", SqlDbType.NVarChar),
                        new SqlParameter("@pass", SqlDbType.NVarChar),
                        new SqlParameter("@name", SqlDbType.NVarChar),
                        new SqlParameter("@email", SqlDbType.NVarChar),
                    };
                    
                    //为此参数数组进行赋值
                    pars[0].Value = id;
                    pars[1].Value = pass;
                    pars[2].Value = name;
                    pars[3].Value = email;

                    cmd.Parameters.AddRange(pars); //将参数数组中的数据添加到sql语句中去

                    //-----------------------------------
                    conn.Open();  //打开数据库链接
                    i = cmd.ExecuteNonQuery();   //执行insert语句后返回影响行数
                            
                }
            }

            if (i > 0)
            {
                context.Response.Redirect("UserInfoList.ashx");
            }
            else
            {
                context.Response.Write("添加失败");
            }
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}