﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace hua.test.FileUpLoad
{
    /// <summary>
    /// DownLoad 的摘要说明
    /// </summary>
    public class DownLoad : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/plain";
            //context.Response.Write("Hello World");

            //string hua_id = context.Request.QueryString["hhh_id"];
            string encodeFileName = "123.txt"; //文件名
            //在响应头加上Content-Disposition，  而attachment 表示以附件的形式下载
            context.Response.AddHeader("Content-Disposition", string.Format("attachment;filename=\"{0}\"",encodeFileName));
            context.Response.WriteFile(encodeFileName);
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}