﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;

namespace hua.test.FileUpLoad
{
    /// <summary>
    /// FileUpLoad 的摘要说明
    /// </summary>
    public class FileUpLoad : IHttpHandler
    {
        private readonly static string connStr = ConfigurationManager.ConnectionStrings["connStr"].ConnectionString;
        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/html";
            //context.Response.Write("Hello World");
                                                   
            string imgInfo = context.Request.Form["imageInfo"];//获取图片的介绍
            HttpPostedFile file = context.Request.Files["fileUp"];//获取上传的图片
            


            string id = context.Request.Form["FileUpLoad_Html_id"];

            //不允许没有登录就直接上传照片， 所以做一个判断
            if (id == null || id == "" || id == "$id")
            {
                //得到index.html的绝对路径 
                string filePath = context.Request.MapPath("/index.html");
                //得到index.html里面的文本内容 
                string fileContext = File.ReadAllText(filePath);
                //把文本里指的内容进行替换
                fileContext = fileContext.Replace("<span></span>", "请先登录再进行文件上传");
                //将替换后的内容输出到客户端(浏览器)
                context.Response.Write(fileContext);
                return;//终此当前方法
            }


            //不允许没有选择就直接上传照片， 所以做一个判断
            if (file != null && !file.FileName.Equals(""))
            {
                string fileName = file.FileName;//得到上传图片的文件名字
                string ext = Path.GetExtension(fileName);


                if (ext == ".jpg" || ext == ".gif" || ext == ".png" || ext == ".jpeg")
                {
                    string newFileNames = Guid.NewGuid().ToString() + ext;
                    //创建文件夹
                    //D:/New_Project/ASP_NET/hua.test/hua.test/img/2018-4-13
                    Directory.CreateDirectory(Path.GetDirectoryName(context.Request.MapPath("/img/" + DateTime.Now.Year + "-" + DateTime.Now.Month + "-" + DateTime.Now.Day + "/")));

                    //img文件夹前面在加一个/表示为根目录(一级目录)
                    string fileSavePath = context.Request.MapPath("/img/" + DateTime.Now.Year + "-" + DateTime.Now.Month + "-" + DateTime.Now.Day + "/" + newFileNames);

                    file.SaveAs(fileSavePath);//保存图片到服务器指定的目录中去

                    using (Image imge = Image.FromStream(file.InputStream))//根据上传的文件流创建Image
                    {   //创建一个位图对象 .设置宽高.它与我们上传的图片宽高一致
                        using (Bitmap map = new Bitmap(imge.Width, imge.Height))
                        {
                            using (Graphics g = Graphics.FromImage(map))
                            {
                                //设置高质量插值法
                                g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.High;
                                //设置高质量,低速度呈现平滑程度
                                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
                                //先将图片画到画布上.
                                g.DrawImage(imge, new Rectangle(0, 0, imge.Width, imge.Height));
                                //在右下角添加水印.
                                g.DrawString("湖北理工学院", new Font("黑体", 14.0f, FontStyle.Bold), Brushes.Red, new PointF(imge.Width - 150, imge.Height - 30));
                                map.Save(context.Request.MapPath("/img/" + DateTime.Now.Year + "-" + DateTime.Now.Month + "-" + DateTime.Now.Day + "/" + newFileNames), System.Drawing.Imaging.ImageFormat.Jpeg);
                            }
                        }
                    }

                    int i;
                    using (SqlConnection conn = new SqlConnection(connStr))
                    {
                        string sql = "insert  into Table_Image values(@iuserid,@ipath,@iimageinfo)";
                        using (SqlCommand cmd = new SqlCommand(sql, conn))
                        {
                            SqlParameter[] pars = { new SqlParameter("@iuserid", SqlDbType.NVarChar),
                                                    new SqlParameter("@ipath",SqlDbType.NVarChar),
                                                    new SqlParameter("@iimageinfo",SqlDbType.NVarChar)
                                                  };
                            pars[0].Value = id;
                            pars[1].Value = "/img/" + DateTime.Now.Year + "-" + DateTime.Now.Month + "-" + DateTime.Now.Day + "/" + newFileNames;
                            pars[2].Value = imgInfo;

                            //context.Response.Write(pars[0].Value);
                            //context.Response.Write(pars[1].Value);
                            //context.Response.Write(pars[2].Value);

                            cmd.Parameters.AddRange(pars);

                            conn.Open();
                            i = cmd.ExecuteNonQuery();
                        }
                    }

                    if (i > 0) //上传成功
                    {
                        context.Response.Write("<html><head></head><body><img src='" + "/img/" + DateTime.Now.Year + "-" + DateTime.Now.Month + "-" + DateTime.Now.Day + "/" + newFileNames + "'/></body></html>");

                    }
                    else
                    {
                        context.Response.Write("上传失败!");
                    }


                }
                else
                {
                    context.Response.Write("您上传的文件类型不对,请重新选择!");
                }
                    
            }
            else
            {
                context.Response.Write("请选择文件!");
            }


    }

    public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}