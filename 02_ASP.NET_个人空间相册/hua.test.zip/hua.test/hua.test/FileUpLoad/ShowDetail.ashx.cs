﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;

namespace hua.test.FileUpLoad
{
    /// <summary>
    /// ShowDetail 的摘要说明
    /// </summary>
    public class ShowDetail : IHttpHandler
    {
        private readonly static string connStr = ConfigurationManager.ConnectionStrings["connStr"].ConnectionString;
        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/html";
            //context.Response.Write("Hello World");


            string s_id = context.Request.QueryString["id"];

            if (s_id == "" || s_id == null || s_id == "$id")
            {
                //得到index.html的绝对路径 
                string filePath = context.Request.MapPath("/index.html");
                //得到index.html里面的文本内容 
                string fileContext = File.ReadAllText(filePath);
                //把文本里指的内容进行替换
                fileContext = fileContext.Replace("<span></span>", "请先登录再进行相册查询");
                //将替换后的内容输出到客户端(浏览器)
                context.Response.Write(fileContext);
                return;//终此当前方法
            }

       
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                string sql = "select * from Table_Image where i_userId = @userid";
                using (SqlDataAdapter adper = new SqlDataAdapter(sql, conn))
                {
                    SqlParameter[] pars = { new SqlParameter("@userid", SqlDbType.NVarChar) };
                    pars[0].Value = s_id;
                    adper.SelectCommand.Parameters.AddRange(pars);
                    DataTable dt = new DataTable();
                    adper.Fill(dt);

                    //ShowDetail.html的绝对路径  
                    string filePath = context.Request.MapPath("ShowDetail.html");
                    //ShowDetail.html里面的文本内容 
                    string fileContext = File.ReadAllText(filePath);

                    StringBuilder builer = new StringBuilder();
                    foreach (DataRow row in dt.Rows)
                    {                                                                                                      //D:\New_Project\ASP_NET\hua.test\hua.test\FileUpLoad\DownLoad.ashx.cs  id =s_id
                        builer.AppendFormat("<tr><td><img width='100' height='100' src='{0}'/></td><td>{1}</td><td><a href='/FileUpLoad/DownLoad.ashx?'>下载</a></td></tr>", row["i_path"].ToString(), row["i_imageInfo"].ToString());
                    }
                    //把文本里指的内容进行替换
                    fileContext = fileContext.Replace("$tbody", builer.ToString());
                    //将替换后的内容输出到客户端(浏览器)
                    context.Response.Write(fileContext);
                }
            }

        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}