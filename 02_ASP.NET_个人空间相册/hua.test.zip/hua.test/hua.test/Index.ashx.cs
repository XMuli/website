﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;

namespace hua.test
{
    /// <summary>
    /// Index 的摘要说明
    /// </summary>
    public class Index : IHttpHandler
    {
        private readonly static string connStr = ConfigurationManager.ConnectionStrings["connStr"].ConnectionString;

        public void ProcessRequest(HttpContext context)
        {
            //Response:服务器对客户端的响应
            context.Response.ContentType = "text/html";  
            //context.Response.Write("Hello World");

            string id = context.Request.Form["username"];
            string pass = context.Request.Form["userpass"];

            //*****************************************************************************************************
            //方式一：手动验证的账号密码
            //if (name.Equals("admin") && pass.Equals("123"))
            //{
            //    //重定向进行跳转
            //    context.Response.Redirect("HtmlPage1.html");
            //}
            //else
            //{
            //    string filePath = context.Request.MapPath("Index.html");  //得到指定文件的绝对路径
            //    string fileContext = File.ReadAllText(filePath);  //得到index.html里面的文本内容 
            //    fileContext = fileContext.Replace("$msg", "<h1>您输入的账号或者密码错误,请重新输入!</h1>");  //把文本里指的内容进行替换
            //    context.Response.Write(fileContext);  //将替换后的内容输出到客户端(浏览器)
            //}
            //*****************************************************************************************************


      //      SELECT [s_id]
      //,[s_passed]
      //,[s_name]
      //,[s_time]
      //,[s_email]

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                string sql = "select * from dbo.Table_1 where @s_id = s_id and @s_passed = s_passed";
                using (SqlDataAdapter adapter = new SqlDataAdapter(sql, connStr))
                {
                    SqlParameter[] pars = { new SqlParameter("@s_id", SqlDbType.NVarChar),
                                            new SqlParameter("@s_passed", SqlDbType.NVarChar)};

                    pars[0].Value = id;
                    pars[1].Value = pass;
                    adapter.SelectCommand.Parameters.AddRange(pars);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);


                    if (dt.Rows.Count > 0)
                    {
                       
                         DataRow row = dt.Rows[0];//取第一行数据  fileupload
                        string filePath = context.Request.MapPath("fileupload/fileupload.html");
                        string fileContext = File.ReadAllText(filePath);
                        fileContext = fileContext.Replace("$id", id);
                        context.Response.Write(fileContext);
                        // context.Response.Redirect("fileupload/FileUpload.html?id=203");//重定向跳转
                    }
                    else
                    {
                        string filePath = context.Request.MapPath("index.html");
                        string fileContext = File.ReadAllText(filePath);
                        fileContext = fileContext.Replace("<span></span>", "输入的用户名或者密码错误 ,请重新输入");
                        context.Response.Write(fileContext);
                    }


                }

            }


        }



        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}