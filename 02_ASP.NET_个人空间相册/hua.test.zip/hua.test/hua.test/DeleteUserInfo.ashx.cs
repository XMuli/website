﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.IO;
using System.Configuration;
using System.Data;

namespace hua.test
{
    /// <summary>
    /// DeleteUserInfo 的摘要说明
    /// </summary>
    public class DeleteUserInfo : IHttpHandler
    {
        //private readonly static string connStr = "server=10.83.48.8; uid=sa; pwd=Aq123456; database=huahua";
        private readonly static string connStr = ConfigurationManager.ConnectionStrings["connStr"].ConnectionString;
        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/html";
            //context.Response.Write("Hello World");


            string hua_id = context.Request.QueryString["hhh_id"];
            //强制转换  Int32.Parse()
            //int id = Int32.Parse(context.Request.QueryString["hua_id"]);   //此方法针对get方式提交时获取参数值   //我的本来就是char型的 不需要强制转换
            int i = 0;
            using (SqlConnection conn = new SqlConnection(connStr))
            {

                string sql = "DELETE FROM dbo.Table_1 WHERE s_id = @hua_id";
                //context.Response.Write(@hua_id);
                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    //设置相应的参数          new SqlParameter("@id", SqlDbType.NVarChar),
                    SqlParameter[] pars = { new SqlParameter("@hua_id", SqlDbType.NVarChar) };
                    pars[0].Value = hua_id;
                    
                    cmd.Parameters.AddRange(pars);  //将参数数组中的数据添加到sql语句中去

                    conn.Open();
                    i = cmd.ExecuteNonQuery();  //执行删除 语句 后返回影响行
                    //context.Response.Write(i);
                }


                if (i > 0)
                {
                     context.Response.Redirect("UserInfoList.ashx");
                }
                else
                {
                    context.Response.Write("删除失败!");
                }




            }
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}