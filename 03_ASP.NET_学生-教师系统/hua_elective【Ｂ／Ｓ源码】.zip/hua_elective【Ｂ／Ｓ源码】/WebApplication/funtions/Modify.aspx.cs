﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using hua_elective.Model;
using hua_elective.BLL;
using hua_elective.DAL;

namespace WebApplication.funtions
{
    public partial class Modify : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            StudentDao student_dao = new StudentDao();
            StudentModel student_temp = new StudentModel();
            //student_temp.s_number = ((StudentModel)Session["student_session"]).s_number;
            student_temp.s_number = 1;
            student_temp.s_user_name = Request.Form["username"];
            student_temp.s_user_password = Request.Form["userpass"];
            student_temp.s_name = Request.Form["name"];
            student_temp.s_age = Request.Form["age"];
            student_temp.s_sex = Request.Form["sex"];

            student_dao.Update(student_temp);



        }
    }
}