﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using hua_elective.Model;
using hua_elective.BLL;
using hua_elective.DAL;

namespace WebApplication.funtions
{
    public partial class ScoreInquiry : System.Web.UI.Page
    {
        public List<StudentModel> student_list;
        public List<ScoureModel> scoure_list;
        public StudentModel student_temp;
        public List<CourseModel> course_list;
        protected void Page_Load(object sender, EventArgs e)
        {
            student_temp = new StudentModel();
            student_temp.s_user_name = ((StudentModel)Session["student_session"]).s_user_name;
            student_temp.s_user_password = ((StudentModel)Session["student_session"]).s_user_password;
            student_temp.s_name = ((StudentModel)Session["student_session"]).s_name;
            student_temp.s_age = ((StudentModel)Session["student_session"]).s_age;
            student_temp.s_sex = ((StudentModel)Session["student_session"]).s_sex;

            StudentServices student_services = new StudentServices();
            ScoureServices scoure_services = new ScoureServices();
            CourseServices course_services = new CourseServices();
            
            

            int temp_s_number = ((StudentModel)Session["student_session"]).s_number;


            scoure_list = scoure_services.GetModelList("s_number = "+ temp_s_number);

            foreach (ScoureModel scoure in scoure_list)
            {
                course_list = course_services.GetModelList("c_number = "+ scoure.c_number);
            }


        }
    }
}