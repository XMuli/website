﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using hua_elective.Model;
using hua_elective.BLL;

namespace WebApplication.funtions
{
    public partial class Insert : System.Web.UI.Page
    {
        public StudentModel student { set; get; }
        protected void Page_Load(object sender, EventArgs e)
        {
            student = new StudentModel();
            student = (StudentModel)Session["student_session"];

            if (this.IsPostBack)
            {
                //优化区域
                //username userpass    name age  sex addr
                //string username = Request.Form["username"];
                //string userpass = Request.Form["userpass"];
                //string name = Request.Form["name"];
                //string age = Request.Form["age"];
                //string sex = Request.Form["sex"];
                //string addr = Request.Form["addr"];

                StudentModel student_temp = new StudentModel();
                student_temp.s_user_name = Request.Form["username"];
                student_temp.s_user_password = Request.Form["userpass"];
                student_temp.s_name = Request.Form["name"];
                student_temp.s_age = Request.Form["age"];
                student_temp.s_sex = Request.Form["sex"];

                if(student_temp.s_user_name != student.s_user_name)
                {
                    StudentServices student_services = new StudentServices();
                    if(student_services.Add(student_temp) > 0)
                    {
                        Response.Write("插入数据成功");
                    }
                    else
                    {
                        Response.Write("插入数据失败");
                    }
                }





            }

        }
    }
}