﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using hua_elective.Model;
using hua_elective.BLL;
using hua_elective.DAL;


namespace WebApplication.funtions
{
    public partial class Desktop : System.Web.UI.Page
    {
        public List<AnnouncementModel> announ_list { set; get; }
        public int n { set; get; }
        protected void Page_Load(object sender, EventArgs e)
        {
            n = 0;
            AnnouncementServices temp = new AnnouncementServices();
            announ_list = temp.GetModelList("");
            n = 1;

        }
    }
}