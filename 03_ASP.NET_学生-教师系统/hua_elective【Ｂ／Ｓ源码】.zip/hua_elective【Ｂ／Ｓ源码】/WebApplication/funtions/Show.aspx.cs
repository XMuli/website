﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using hua_elective.BLL;
using hua_elective.Model;

namespace WebApplication.funtions
{
    public partial class Show : System.Web.UI.Page
    {
        public List<StudentModel> student_list;
        protected void Page_Load(object sender, EventArgs e)
        {
            
            StudentServices student_services = new StudentServices();
            student_list =  student_services.GetModelList("");

        }
    }
}