﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using hua_elective.Model;
using hua_elective.DAL;
using hua_elective.BLL;

namespace WebApplication
{
    public partial class Index : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (this.IsPostBack)
            {
                string username = Request.Form["username"];
                string userpass = Request.Form["userpass"];

                StudentModel stu_mod = new StudentModel();
                StudentDao stu_dao = new StudentDao();
                stu_mod = stu_dao.GetModel(username);
                if (stu_mod != null)
                {
                    Session["student_session"] = stu_mod;
                }
                else
                {
                    Session["student_session"] = null;
                }

                StudentServices student = new StudentServices();
                if (student.My_Exists_user(username, userpass))
                {
                    //Response.Redirect("success.html");
                    Response.Redirect("/funtions/Show.aspx");
                }

            }

        }
    }
}