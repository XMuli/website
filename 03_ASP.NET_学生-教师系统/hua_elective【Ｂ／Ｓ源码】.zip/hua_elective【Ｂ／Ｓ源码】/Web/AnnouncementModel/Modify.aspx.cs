﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
using Maticsoft.Common;
using LTP.Accounts.Bus;
namespace hua_elective.Web.AnnouncementModel
{
    public partial class Modify : Page
    {       

        		protected void Page_Load(object sender, EventArgs e)
		{
			if (!Page.IsPostBack)
			{
				if (Request.Params["id"] != null && Request.Params["id"].Trim() != "")
				{
					int a_number=(Convert.ToInt32(Request.Params["id"]));
					ShowInfo(a_number);
				}
			}
		}
			
	private void ShowInfo(int a_number)
	{
		hua_elective.BLL.AnnouncementServices bll=new hua_elective.BLL.AnnouncementServices();
		hua_elective.Model.AnnouncementModel model=bll.GetModel(a_number);
		this.lbla_number.Text=model.a_number.ToString();
		this.txta_content.Text=model.a_content;

	}

		public void btnSave_Click(object sender, EventArgs e)
		{
			
			string strErr="";
			if(this.txta_content.Text.Trim().Length==0)
			{
				strErr+="a_content不能为空！\\n";	
			}

			if(strErr!="")
			{
				MessageBox.Show(this,strErr);
				return;
			}
			int a_number=int.Parse(this.lbla_number.Text);
			string a_content=this.txta_content.Text;


			hua_elective.Model.AnnouncementModel model=new hua_elective.Model.AnnouncementModel();
			model.a_number=a_number;
			model.a_content=a_content;

			hua_elective.BLL.AnnouncementServices bll=new hua_elective.BLL.AnnouncementServices();
			bll.Update(model);
			Maticsoft.Common.MessageBox.ShowAndRedirect(this,"保存成功！","list.aspx");

		}


        public void btnCancle_Click(object sender, EventArgs e)
        {
            Response.Redirect("list.aspx");
        }
    }
}
