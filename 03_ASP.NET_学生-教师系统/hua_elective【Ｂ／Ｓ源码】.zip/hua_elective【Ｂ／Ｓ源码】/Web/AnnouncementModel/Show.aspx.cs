﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
namespace hua_elective.Web.AnnouncementModel
{
    public partial class Show : Page
    {        
        		public string strid=""; 
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!Page.IsPostBack)
			{
				if (Request.Params["id"] != null && Request.Params["id"].Trim() != "")
				{
					strid = Request.Params["id"];
					int a_number=(Convert.ToInt32(strid));
					ShowInfo(a_number);
				}
			}
		}
		
	private void ShowInfo(int a_number)
	{
		hua_elective.BLL.AnnouncementServices bll=new hua_elective.BLL.AnnouncementServices();
		hua_elective.Model.AnnouncementModel model=bll.GetModel(a_number);
		this.lbla_number.Text=model.a_number.ToString();
		this.lbla_content.Text=model.a_content;

	}


    }
}
