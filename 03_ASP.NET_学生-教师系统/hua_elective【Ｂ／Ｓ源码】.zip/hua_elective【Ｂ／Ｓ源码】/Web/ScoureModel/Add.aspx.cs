﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
using Maticsoft.Common;
using LTP.Accounts.Bus;
namespace hua_elective.Web.ScoureModel
{
    public partial class Add : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
                       
        }

        		protected void btnSave_Click(object sender, EventArgs e)
		{
			
			string strErr="";
			if(!PageValidate.IsNumber(txts_number.Text))
			{
				strErr+="s_number格式错误！\\n";	
			}
			if(!PageValidate.IsNumber(txtc_number.Text))
			{
				strErr+="c_number格式错误！\\n";	
			}
			if(!PageValidate.IsNumber(txtsc_scoure.Text))
			{
				strErr+="sc_scoure格式错误！\\n";	
			}
			if(this.txtsc_check.Text.Trim().Length==0)
			{
				strErr+="sc_check不能为空！\\n";	
			}

			if(strErr!="")
			{
				MessageBox.Show(this,strErr);
				return;
			}
			int s_number=int.Parse(this.txts_number.Text);
			int c_number=int.Parse(this.txtc_number.Text);
			int sc_scoure=int.Parse(this.txtsc_scoure.Text);
			string sc_check=this.txtsc_check.Text;

			hua_elective.Model.ScoureModel model=new hua_elective.Model.ScoureModel();
			model.s_number=s_number;
			model.c_number=c_number;
			model.sc_scoure=sc_scoure;
			model.sc_check=sc_check;

			hua_elective.BLL.ScoureServices bll=new hua_elective.BLL.ScoureServices();
			bll.Add(model);
			Maticsoft.Common.MessageBox.ShowAndRedirect(this,"保存成功！","add.aspx");

		}


        public void btnCancle_Click(object sender, EventArgs e)
        {
            Response.Redirect("list.aspx");
        }
    }
}
