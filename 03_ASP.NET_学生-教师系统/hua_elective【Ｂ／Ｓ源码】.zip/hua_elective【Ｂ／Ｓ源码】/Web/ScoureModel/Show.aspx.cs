﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
namespace hua_elective.Web.ScoureModel
{
    public partial class Show : Page
    {        
        		public string strid=""; 
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!Page.IsPostBack)
			{
				int s_number = -1;
				if (Request.Params["id0"] != null && Request.Params["id0"].Trim() != "")
				{
					s_number=(Convert.ToInt32(Request.Params["id0"]));
				}
				int c_number = -1;
				if (Request.Params["id1"] != null && Request.Params["id1"].Trim() != "")
				{
					c_number=(Convert.ToInt32(Request.Params["id1"]));
				}
				#warning 代码生成提示：显示页面,请检查确认该语句是否正确
				ShowInfo(s_number,c_number);
			}
		}
		
	private void ShowInfo(int s_number,int c_number)
	{
		hua_elective.BLL.ScoureServices bll=new hua_elective.BLL.ScoureServices();
		hua_elective.Model.ScoureModel model=bll.GetModel(s_number,c_number);
		this.lbls_number.Text=model.s_number.ToString();
		this.lblc_number.Text=model.c_number.ToString();
		this.lblsc_scoure.Text=model.sc_scoure.ToString();
		this.lblsc_check.Text=model.sc_check;

	}


    }
}
