﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
using Maticsoft.Common;
using LTP.Accounts.Bus;
namespace hua_elective.Web.StudentModel
{
    public partial class Modify : Page
    {       

        		protected void Page_Load(object sender, EventArgs e)
		{
			if (!Page.IsPostBack)
			{
				if (Request.Params["id"] != null && Request.Params["id"].Trim() != "")
				{
					int s_number=(Convert.ToInt32(Request.Params["id"]));
					ShowInfo(s_number);
				}
			}
		}
			
	private void ShowInfo(int s_number)
	{
		hua_elective.BLL.StudentServices bll=new hua_elective.BLL.StudentServices();
		hua_elective.Model.StudentModel model=bll.GetModel(s_number);
		this.lbls_number.Text=model.s_number.ToString();
		this.lbls_user_name.Text=model.s_user_name;
		this.txts_user_password.Text=model.s_user_password;
		this.txts_name.Text=model.s_name;
		this.txts_age.Text=model.s_age;
		this.txts_sex.Text=model.s_sex;

	}

		public void btnSave_Click(object sender, EventArgs e)
		{
			
			string strErr="";
			if(this.txts_user_password.Text.Trim().Length==0)
			{
				strErr+="s_user_password不能为空！\\n";	
			}
			if(this.txts_name.Text.Trim().Length==0)
			{
				strErr+="s_name不能为空！\\n";	
			}
			if(this.txts_age.Text.Trim().Length==0)
			{
				strErr+="s_age不能为空！\\n";	
			}
			if(this.txts_sex.Text.Trim().Length==0)
			{
				strErr+="s_sex不能为空！\\n";	
			}

			if(strErr!="")
			{
				MessageBox.Show(this,strErr);
				return;
			}
			int s_number=int.Parse(this.lbls_number.Text);
			string s_user_name=this.lbls_user_name.Text;
			string s_user_password=this.txts_user_password.Text;
			string s_name=this.txts_name.Text;
			string s_age=this.txts_age.Text;
			string s_sex=this.txts_sex.Text;


			hua_elective.Model.StudentModel model=new hua_elective.Model.StudentModel();
			model.s_number=s_number;
			model.s_user_name=s_user_name;
			model.s_user_password=s_user_password;
			model.s_name=s_name;
			model.s_age=s_age;
			model.s_sex=s_sex;

			hua_elective.BLL.StudentServices bll=new hua_elective.BLL.StudentServices();
			bll.Update(model);
			Maticsoft.Common.MessageBox.ShowAndRedirect(this,"保存成功！","list.aspx");

		}


        public void btnCancle_Click(object sender, EventArgs e)
        {
            Response.Redirect("list.aspx");
        }
    }
}
