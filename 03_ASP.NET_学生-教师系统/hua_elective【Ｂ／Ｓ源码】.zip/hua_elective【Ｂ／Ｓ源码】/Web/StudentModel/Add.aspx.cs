﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
using Maticsoft.Common;
using LTP.Accounts.Bus;
namespace hua_elective.Web.StudentModel
{
    public partial class Add : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
                       
        }

        		protected void btnSave_Click(object sender, EventArgs e)
		{
			
			string strErr="";
			if(this.txts_user_name.Text.Trim().Length==0)
			{
				strErr+="s_user_name不能为空！\\n";	
			}
			if(this.txts_user_password.Text.Trim().Length==0)
			{
				strErr+="s_user_password不能为空！\\n";	
			}
			if(this.txts_name.Text.Trim().Length==0)
			{
				strErr+="s_name不能为空！\\n";	
			}
			if(this.txts_age.Text.Trim().Length==0)
			{
				strErr+="s_age不能为空！\\n";	
			}
			if(this.txts_sex.Text.Trim().Length==0)
			{
				strErr+="s_sex不能为空！\\n";	
			}

			if(strErr!="")
			{
				MessageBox.Show(this,strErr);
				return;
			}
			string s_user_name=this.txts_user_name.Text;
			string s_user_password=this.txts_user_password.Text;
			string s_name=this.txts_name.Text;
			string s_age=this.txts_age.Text;
			string s_sex=this.txts_sex.Text;

			hua_elective.Model.StudentModel model=new hua_elective.Model.StudentModel();
			model.s_user_name=s_user_name;
			model.s_user_password=s_user_password;
			model.s_name=s_name;
			model.s_age=s_age;
			model.s_sex=s_sex;

			hua_elective.BLL.StudentServices bll=new hua_elective.BLL.StudentServices();
			bll.Add(model);
			Maticsoft.Common.MessageBox.ShowAndRedirect(this,"保存成功！","add.aspx");

		}


        public void btnCancle_Click(object sender, EventArgs e)
        {
            Response.Redirect("list.aspx");
        }
    }
}
