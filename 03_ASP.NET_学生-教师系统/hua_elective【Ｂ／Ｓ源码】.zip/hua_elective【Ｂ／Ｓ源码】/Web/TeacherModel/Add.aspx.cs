﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
using Maticsoft.Common;
using LTP.Accounts.Bus;
namespace hua_elective.Web.TeacherModel
{
    public partial class Add : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
                       
        }

        		protected void btnSave_Click(object sender, EventArgs e)
		{
			
			string strErr="";
			if(this.txtt_user_name.Text.Trim().Length==0)
			{
				strErr+="t_user_name不能为空！\\n";	
			}
			if(this.txtt_user_password.Text.Trim().Length==0)
			{
				strErr+="t_user_password不能为空！\\n";	
			}
			if(this.txtt_name.Text.Trim().Length==0)
			{
				strErr+="t_name不能为空！\\n";	
			}
			if(this.txtt_age.Text.Trim().Length==0)
			{
				strErr+="t_age不能为空！\\n";	
			}
			if(this.txtt_sex.Text.Trim().Length==0)
			{
				strErr+="t_sex不能为空！\\n";	
			}

			if(strErr!="")
			{
				MessageBox.Show(this,strErr);
				return;
			}
			string t_user_name=this.txtt_user_name.Text;
			string t_user_password=this.txtt_user_password.Text;
			string t_name=this.txtt_name.Text;
			string t_age=this.txtt_age.Text;
			string t_sex=this.txtt_sex.Text;

			hua_elective.Model.TeacherModel model=new hua_elective.Model.TeacherModel();
			model.t_user_name=t_user_name;
			model.t_user_password=t_user_password;
			model.t_name=t_name;
			model.t_age=t_age;
			model.t_sex=t_sex;

			hua_elective.BLL.TeacherServices bll=new hua_elective.BLL.TeacherServices();
			bll.Add(model);
			Maticsoft.Common.MessageBox.ShowAndRedirect(this,"保存成功！","add.aspx");

		}


        public void btnCancle_Click(object sender, EventArgs e)
        {
            Response.Redirect("list.aspx");
        }
    }
}
