﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
using Maticsoft.Common;
using LTP.Accounts.Bus;
namespace hua_elective.Web.TeacherModel
{
    public partial class Modify : Page
    {       

        		protected void Page_Load(object sender, EventArgs e)
		{
			if (!Page.IsPostBack)
			{
				if (Request.Params["id"] != null && Request.Params["id"].Trim() != "")
				{
					int t_number=(Convert.ToInt32(Request.Params["id"]));
					ShowInfo(t_number);
				}
			}
		}
			
	private void ShowInfo(int t_number)
	{
		hua_elective.BLL.TeacherServices bll=new hua_elective.BLL.TeacherServices();
		hua_elective.Model.TeacherModel model=bll.GetModel(t_number);
		this.lblt_number.Text=model.t_number.ToString();
		this.lblt_user_name.Text=model.t_user_name;
		this.txtt_user_password.Text=model.t_user_password;
		this.txtt_name.Text=model.t_name;
		this.txtt_age.Text=model.t_age;
		this.txtt_sex.Text=model.t_sex;

	}

		public void btnSave_Click(object sender, EventArgs e)
		{
			
			string strErr="";
			if(this.txtt_user_password.Text.Trim().Length==0)
			{
				strErr+="t_user_password不能为空！\\n";	
			}
			if(this.txtt_name.Text.Trim().Length==0)
			{
				strErr+="t_name不能为空！\\n";	
			}
			if(this.txtt_age.Text.Trim().Length==0)
			{
				strErr+="t_age不能为空！\\n";	
			}
			if(this.txtt_sex.Text.Trim().Length==0)
			{
				strErr+="t_sex不能为空！\\n";	
			}

			if(strErr!="")
			{
				MessageBox.Show(this,strErr);
				return;
			}
			int t_number=int.Parse(this.lblt_number.Text);
			string t_user_name=this.lblt_user_name.Text;
			string t_user_password=this.txtt_user_password.Text;
			string t_name=this.txtt_name.Text;
			string t_age=this.txtt_age.Text;
			string t_sex=this.txtt_sex.Text;


			hua_elective.Model.TeacherModel model=new hua_elective.Model.TeacherModel();
			model.t_number=t_number;
			model.t_user_name=t_user_name;
			model.t_user_password=t_user_password;
			model.t_name=t_name;
			model.t_age=t_age;
			model.t_sex=t_sex;

			hua_elective.BLL.TeacherServices bll=new hua_elective.BLL.TeacherServices();
			bll.Update(model);
			Maticsoft.Common.MessageBox.ShowAndRedirect(this,"保存成功！","list.aspx");

		}


        public void btnCancle_Click(object sender, EventArgs e)
        {
            Response.Redirect("list.aspx");
        }
    }
}
