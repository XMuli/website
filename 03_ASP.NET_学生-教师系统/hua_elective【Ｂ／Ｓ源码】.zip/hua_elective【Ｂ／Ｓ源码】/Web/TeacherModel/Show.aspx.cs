﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
namespace hua_elective.Web.TeacherModel
{
    public partial class Show : Page
    {        
        		public string strid=""; 
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!Page.IsPostBack)
			{
				if (Request.Params["id"] != null && Request.Params["id"].Trim() != "")
				{
					strid = Request.Params["id"];
					int t_number=(Convert.ToInt32(strid));
					ShowInfo(t_number);
				}
			}
		}
		
	private void ShowInfo(int t_number)
	{
		hua_elective.BLL.TeacherServices bll=new hua_elective.BLL.TeacherServices();
		hua_elective.Model.TeacherModel model=bll.GetModel(t_number);
		this.lblt_number.Text=model.t_number.ToString();
		this.lblt_user_name.Text=model.t_user_name;
		this.lblt_user_password.Text=model.t_user_password;
		this.lblt_name.Text=model.t_name;
		this.lblt_age.Text=model.t_age;
		this.lblt_sex.Text=model.t_sex;

	}


    }
}
