﻿using System;
using System.Data;
using System.Text;
using System.Data.SqlClient;
using Maticsoft.DBUtility;//Please add references
namespace hua_elective.DAL
{
	/// <summary>
	/// 数据访问类:StudentDao
	/// </summary>
	public partial class StudentDao
	{
		public StudentDao()
		{}
		#region  BasicMethod

                /// <summary>
        /// 得到一个对象实体by  s_user_name
        /// </summary>
        public hua_elective.Model.StudentModel GetModel(string s_user_name)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select  top 1 s_number,s_user_name,s_user_password,s_name,s_age,s_sex from Student ");
            strSql.Append(" where s_user_name=@@SQL2012s_user_name");
            SqlParameter[] parameters = {
                    new SqlParameter("@@SQL2012s_user_name", SqlDbType.VarChar)
            };
            parameters[0].Value = s_user_name;

            hua_elective.Model.StudentModel model = new hua_elective.Model.StudentModel();
            DataSet ds = DbHelperSQL.Query(strSql.ToString(), parameters);
            if (ds.Tables[0].Rows.Count > 0)
            {
                return DataRowToModel(ds.Tables[0].Rows[0]);
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// 该学生账号是否存
        /// </summary>
        public bool My_Exists_user(string s_user_name, string s_user_password)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select count(1) from Student");
            strSql.Append(" where s_user_name=@@SQL2012s_user_name and s_user_password=@@SQL2012s_user_password ");
            SqlParameter[] parameters = {
                    new SqlParameter("@@SQL2012s_user_name", SqlDbType.VarChar),
                    new SqlParameter("@@SQL2012s_user_password", SqlDbType.VarChar)            };
            parameters[0].Value = s_user_name;
            parameters[1].Value = s_user_password;

            return DbHelperSQL.Exists(strSql.ToString(), parameters);
        }

		/// <summary>
		/// 得到最大ID
		/// </summary>
		public int GetMaxId()
		{
		return DbHelperSQL.GetMaxID("s_number", "Student"); 
		}

		/// <summary>
		/// 是否存在该记录
		/// </summary>
		public bool Exists(string s_user_name,int s_number)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select count(1) from Student");
			strSql.Append(" where s_user_name=@SQL2012s_user_name and s_number=@SQL2012s_number ");
			SqlParameter[] parameters = {
					new SqlParameter("@SQL2012s_user_name", SqlDbType.VarChar,20),
					new SqlParameter("@SQL2012s_number", SqlDbType.Int,4)			};
			parameters[0].Value = s_user_name;
			parameters[1].Value = s_number;

			return DbHelperSQL.Exists(strSql.ToString(),parameters);
		}


		/// <summary>
		/// 增加一条数据
		/// </summary>
		public int Add(hua_elective.Model.StudentModel model)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("insert into Student(");
			strSql.Append("s_user_name,s_user_password,s_name,s_age,s_sex)");
			strSql.Append(" values (");
			strSql.Append("@SQL2012s_user_name,@SQL2012s_user_password,@SQL2012s_name,@SQL2012s_age,@SQL2012s_sex)");
			strSql.Append(";select @@IDENTITY");
			SqlParameter[] parameters = {
					new SqlParameter("@SQL2012s_user_name", SqlDbType.VarChar,20),
					new SqlParameter("@SQL2012s_user_password", SqlDbType.VarChar,20),
					new SqlParameter("@SQL2012s_name", SqlDbType.VarChar,20),
					new SqlParameter("@SQL2012s_age", SqlDbType.Char,4),
					new SqlParameter("@SQL2012s_sex", SqlDbType.Char,2)};
			parameters[0].Value = model.s_user_name;
			parameters[1].Value = model.s_user_password;
			parameters[2].Value = model.s_name;
			parameters[3].Value = model.s_age;
			parameters[4].Value = model.s_sex;

			object obj = DbHelperSQL.GetSingle(strSql.ToString(),parameters);
			if (obj == null)
			{
				return 0;
			}
			else
			{
				return Convert.ToInt32(obj);
			}
		}
		/// <summary>
		/// 更新一条数据
		/// </summary>
		public bool Update(hua_elective.Model.StudentModel model)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("update Student set ");
			strSql.Append("s_user_password=@SQL2012s_user_password,");
			strSql.Append("s_name=@SQL2012s_name,");
			strSql.Append("s_age=@SQL2012s_age,");
			strSql.Append("s_sex=@SQL2012s_sex");
			strSql.Append(" where s_number=@SQL2012s_number");
			SqlParameter[] parameters = {
					new SqlParameter("@SQL2012s_user_password", SqlDbType.VarChar,20),
					new SqlParameter("@SQL2012s_name", SqlDbType.VarChar,20),
					new SqlParameter("@SQL2012s_age", SqlDbType.Char,4),
					new SqlParameter("@SQL2012s_sex", SqlDbType.Char,2),
					new SqlParameter("@SQL2012s_number", SqlDbType.Int,4),
					new SqlParameter("@SQL2012s_user_name", SqlDbType.VarChar,20)};
			parameters[0].Value = model.s_user_password;
			parameters[1].Value = model.s_name;
			parameters[2].Value = model.s_age;
			parameters[3].Value = model.s_sex;
			parameters[4].Value = model.s_number;
			parameters[5].Value = model.s_user_name;

			int rows=DbHelperSQL.ExecuteSql(strSql.ToString(),parameters);
			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		/// <summary>
		/// 删除一条数据
		/// </summary>
		public bool Delete(int s_number)
		{
			
			StringBuilder strSql=new StringBuilder();
			strSql.Append("delete from Student ");
			strSql.Append(" where s_number=@SQL2012s_number");
			SqlParameter[] parameters = {
					new SqlParameter("@SQL2012s_number", SqlDbType.Int,4)
			};
			parameters[0].Value = s_number;

			int rows=DbHelperSQL.ExecuteSql(strSql.ToString(),parameters);
			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		/// <summary>
		/// 删除一条数据
		/// </summary>
		public bool Delete(string s_user_name,int s_number)
		{
			
			StringBuilder strSql=new StringBuilder();
			strSql.Append("delete from Student ");
			strSql.Append(" where s_user_name=@SQL2012s_user_name and s_number=@SQL2012s_number ");
			SqlParameter[] parameters = {
					new SqlParameter("@SQL2012s_user_name", SqlDbType.VarChar,20),
					new SqlParameter("@SQL2012s_number", SqlDbType.Int,4)			};
			parameters[0].Value = s_user_name;
			parameters[1].Value = s_number;

			int rows=DbHelperSQL.ExecuteSql(strSql.ToString(),parameters);
			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		/// <summary>
		/// 批量删除数据
		/// </summary>
		public bool DeleteList(string s_numberlist )
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("delete from Student ");
			strSql.Append(" where s_number in ("+s_numberlist + ")  ");
			int rows=DbHelperSQL.ExecuteSql(strSql.ToString());
			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}


		/// <summary>
		/// 得到一个对象实体
		/// </summary>
		public hua_elective.Model.StudentModel GetModel(int s_number)
		{
			
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select  top 1 s_number,s_user_name,s_user_password,s_name,s_age,s_sex from Student ");
			strSql.Append(" where s_number=@SQL2012s_number");
			SqlParameter[] parameters = {
					new SqlParameter("@SQL2012s_number", SqlDbType.Int,4)
			};
			parameters[0].Value = s_number;

			hua_elective.Model.StudentModel model=new hua_elective.Model.StudentModel();
			DataSet ds=DbHelperSQL.Query(strSql.ToString(),parameters);
			if(ds.Tables[0].Rows.Count>0)
			{
				return DataRowToModel(ds.Tables[0].Rows[0]);
			}
			else
			{
				return null;
			}
		}


		/// <summary>
		/// 得到一个对象实体
		/// </summary>
		public hua_elective.Model.StudentModel DataRowToModel(DataRow row)
		{
			hua_elective.Model.StudentModel model=new hua_elective.Model.StudentModel();
			if (row != null)
			{
				if(row["s_number"]!=null && row["s_number"].ToString()!="")
				{
					model.s_number=int.Parse(row["s_number"].ToString());
				}
				if(row["s_user_name"]!=null)
				{
					model.s_user_name=row["s_user_name"].ToString();
				}
				if(row["s_user_password"]!=null)
				{
					model.s_user_password=row["s_user_password"].ToString();
				}
				if(row["s_name"]!=null)
				{
					model.s_name=row["s_name"].ToString();
				}
				if(row["s_age"]!=null)
				{
					model.s_age=row["s_age"].ToString();
				}
				if(row["s_sex"]!=null)
				{
					model.s_sex=row["s_sex"].ToString();
				}
			}
			return model;
		}

		/// <summary>
		/// 获得数据列表
		/// </summary>
		public DataSet GetList(string strWhere)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select s_number,s_user_name,s_user_password,s_name,s_age,s_sex ");
			strSql.Append(" FROM Student ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			return DbHelperSQL.Query(strSql.ToString());
		}

		/// <summary>
		/// 获得前几行数据
		/// </summary>
		public DataSet GetList(int Top,string strWhere,string filedOrder)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select ");
			if(Top>0)
			{
				strSql.Append(" top "+Top.ToString());
			}
			strSql.Append(" s_number,s_user_name,s_user_password,s_name,s_age,s_sex ");
			strSql.Append(" FROM Student ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			strSql.Append(" order by " + filedOrder);
			return DbHelperSQL.Query(strSql.ToString());
		}

		/// <summary>
		/// 获取记录总数
		/// </summary>
		public int GetRecordCount(string strWhere)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select count(1) FROM Student ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			object obj = DbHelperSQL.GetSingle(strSql.ToString());
			if (obj == null)
			{
				return 0;
			}
			else
			{
				return Convert.ToInt32(obj);
			}
		}
		/// <summary>
		/// 分页获取数据列表
		/// </summary>
		public DataSet GetListByPage(string strWhere, string orderby, int startIndex, int endIndex)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("SELECT * FROM ( ");
			strSql.Append(" SELECT ROW_NUMBER() OVER (");
			if (!string.IsNullOrEmpty(orderby.Trim()))
			{
				strSql.Append("order by T." + orderby );
			}
			else
			{
				strSql.Append("order by T.s_number desc");
			}
			strSql.Append(")AS Row, T.*  from Student T ");
			if (!string.IsNullOrEmpty(strWhere.Trim()))
			{
				strSql.Append(" WHERE " + strWhere);
			}
			strSql.Append(" ) TT");
			strSql.AppendFormat(" WHERE TT.Row between {0} and {1}", startIndex, endIndex);
			return DbHelperSQL.Query(strSql.ToString());
		}

		/*
		/// <summary>
		/// 分页获取数据列表
		/// </summary>
		public DataSet GetList(int PageSize,int PageIndex,string strWhere)
		{
			SqlParameter[] parameters = {
					new SqlParameter("@SQL2012tblName", SqlDbType.VarChar, 255),
					new SqlParameter("@SQL2012fldName", SqlDbType.VarChar, 255),
					new SqlParameter("@SQL2012PageSize", SqlDbType.Int),
					new SqlParameter("@SQL2012PageIndex", SqlDbType.Int),
					new SqlParameter("@SQL2012IsReCount", SqlDbType.Bit),
					new SqlParameter("@SQL2012OrderType", SqlDbType.Bit),
					new SqlParameter("@SQL2012strWhere", SqlDbType.VarChar,1000),
					};
			parameters[0].Value = "Student";
			parameters[1].Value = "s_number";
			parameters[2].Value = PageSize;
			parameters[3].Value = PageIndex;
			parameters[4].Value = 0;
			parameters[5].Value = 0;
			parameters[6].Value = strWhere;	
			return DbHelperSQL.RunProcedure("UP_GetRecordByPage",parameters,"ds");
		}*/

		#endregion  BasicMethod
		#region  ExtensionMethod

		#endregion  ExtensionMethod
	}
}

