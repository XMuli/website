﻿using System;
using System.Data;
using System.Text;
using System.Data.SqlClient;
using Maticsoft.DBUtility;//Please add references
namespace hua_elective.DAL
{
	/// <summary>
	/// 数据访问类:ScoureDao
	/// </summary>
	public partial class ScoureDao
	{
		public ScoureDao()
		{}
		#region  BasicMethod



		/// <summary>
		/// 得到最大ID
		/// </summary>
		public int GetMaxId()
		{
		return DbHelperSQL.GetMaxID("s_number", "Scoure"); 
		}

		/// <summary>
		/// 是否存在该记录
		/// </summary>
		public bool Exists(int s_number,int c_number)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select count(1) from Scoure");
			strSql.Append(" where s_number=@SQL2012s_number and c_number=@SQL2012c_number ");
			SqlParameter[] parameters = {
					new SqlParameter("@SQL2012s_number", SqlDbType.Int,4),
					new SqlParameter("@SQL2012c_number", SqlDbType.Int,4)			};
			parameters[0].Value = s_number;
			parameters[1].Value = c_number;

			return DbHelperSQL.Exists(strSql.ToString(),parameters);
		}


		/// <summary>
		/// 增加一条数据
		/// </summary>
		public bool Add(hua_elective.Model.ScoureModel model)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("insert into Scoure(");
			strSql.Append("s_number,c_number,sc_scoure,sc_check)");
			strSql.Append(" values (");
			strSql.Append("@SQL2012s_number,@SQL2012c_number,@SQL2012sc_scoure,@SQL2012sc_check)");
			SqlParameter[] parameters = {
					new SqlParameter("@SQL2012s_number", SqlDbType.Int,4),
					new SqlParameter("@SQL2012c_number", SqlDbType.Int,4),
					new SqlParameter("@SQL2012sc_scoure", SqlDbType.Int,4),
					new SqlParameter("@SQL2012sc_check", SqlDbType.VarChar,50)};
			parameters[0].Value = model.s_number;
			parameters[1].Value = model.c_number;
			parameters[2].Value = model.sc_scoure;
			parameters[3].Value = model.sc_check;

			int rows=DbHelperSQL.ExecuteSql(strSql.ToString(),parameters);
			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		/// <summary>
		/// 更新一条数据
		/// </summary>
		public bool Update(hua_elective.Model.ScoureModel model)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("update Scoure set ");
			strSql.Append("sc_scoure=@SQL2012sc_scoure,");
			strSql.Append("sc_check=@SQL2012sc_check");
			strSql.Append(" where s_number=@SQL2012s_number and c_number=@SQL2012c_number ");
			SqlParameter[] parameters = {
					new SqlParameter("@SQL2012sc_scoure", SqlDbType.Int,4),
					new SqlParameter("@SQL2012sc_check", SqlDbType.VarChar,50),
					new SqlParameter("@SQL2012s_number", SqlDbType.Int,4),
					new SqlParameter("@SQL2012c_number", SqlDbType.Int,4)};
			parameters[0].Value = model.sc_scoure;
			parameters[1].Value = model.sc_check;
			parameters[2].Value = model.s_number;
			parameters[3].Value = model.c_number;

			int rows=DbHelperSQL.ExecuteSql(strSql.ToString(),parameters);
			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		/// <summary>
		/// 删除一条数据
		/// </summary>
		public bool Delete(int s_number,int c_number)
		{
			
			StringBuilder strSql=new StringBuilder();
			strSql.Append("delete from Scoure ");
			strSql.Append(" where s_number=@SQL2012s_number and c_number=@SQL2012c_number ");
			SqlParameter[] parameters = {
					new SqlParameter("@SQL2012s_number", SqlDbType.Int,4),
					new SqlParameter("@SQL2012c_number", SqlDbType.Int,4)			};
			parameters[0].Value = s_number;
			parameters[1].Value = c_number;

			int rows=DbHelperSQL.ExecuteSql(strSql.ToString(),parameters);
			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}


		/// <summary>
		/// 得到一个对象实体
		/// </summary>
		public hua_elective.Model.ScoureModel GetModel(int s_number,int c_number)
		{
			
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select  top 1 s_number,c_number,sc_scoure,sc_check from Scoure ");
			strSql.Append(" where s_number=@SQL2012s_number and c_number=@SQL2012c_number ");
			SqlParameter[] parameters = {
					new SqlParameter("@SQL2012s_number", SqlDbType.Int,4),
					new SqlParameter("@SQL2012c_number", SqlDbType.Int,4)			};
			parameters[0].Value = s_number;
			parameters[1].Value = c_number;

			hua_elective.Model.ScoureModel model=new hua_elective.Model.ScoureModel();
			DataSet ds=DbHelperSQL.Query(strSql.ToString(),parameters);
			if(ds.Tables[0].Rows.Count>0)
			{
				return DataRowToModel(ds.Tables[0].Rows[0]);
			}
			else
			{
				return null;
			}
		}


		/// <summary>
		/// 得到一个对象实体
		/// </summary>
		public hua_elective.Model.ScoureModel DataRowToModel(DataRow row)
		{
			hua_elective.Model.ScoureModel model=new hua_elective.Model.ScoureModel();
			if (row != null)
			{
				if(row["s_number"]!=null && row["s_number"].ToString()!="")
				{
					model.s_number=int.Parse(row["s_number"].ToString());
				}
				if(row["c_number"]!=null && row["c_number"].ToString()!="")
				{
					model.c_number=int.Parse(row["c_number"].ToString());
				}
				if(row["sc_scoure"]!=null && row["sc_scoure"].ToString()!="")
				{
					model.sc_scoure=int.Parse(row["sc_scoure"].ToString());
				}
				if(row["sc_check"]!=null)
				{
					model.sc_check=row["sc_check"].ToString();
				}
			}
			return model;
		}

		/// <summary>
		/// 获得数据列表
		/// </summary>
		public DataSet GetList(string strWhere)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select s_number,c_number,sc_scoure,sc_check ");
			strSql.Append(" FROM Scoure ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			return DbHelperSQL.Query(strSql.ToString());
		}

		/// <summary>
		/// 获得前几行数据
		/// </summary>
		public DataSet GetList(int Top,string strWhere,string filedOrder)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select ");
			if(Top>0)
			{
				strSql.Append(" top "+Top.ToString());
			}
			strSql.Append(" s_number,c_number,sc_scoure,sc_check ");
			strSql.Append(" FROM Scoure ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			strSql.Append(" order by " + filedOrder);
			return DbHelperSQL.Query(strSql.ToString());
		}

		/// <summary>
		/// 获取记录总数
		/// </summary>
		public int GetRecordCount(string strWhere)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select count(1) FROM Scoure ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			object obj = DbHelperSQL.GetSingle(strSql.ToString());
			if (obj == null)
			{
				return 0;
			}
			else
			{
				return Convert.ToInt32(obj);
			}
		}
		/// <summary>
		/// 分页获取数据列表
		/// </summary>
		public DataSet GetListByPage(string strWhere, string orderby, int startIndex, int endIndex)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("SELECT * FROM ( ");
			strSql.Append(" SELECT ROW_NUMBER() OVER (");
			if (!string.IsNullOrEmpty(orderby.Trim()))
			{
				strSql.Append("order by T." + orderby );
			}
			else
			{
				strSql.Append("order by T.c_number desc");
			}
			strSql.Append(")AS Row, T.*  from Scoure T ");
			if (!string.IsNullOrEmpty(strWhere.Trim()))
			{
				strSql.Append(" WHERE " + strWhere);
			}
			strSql.Append(" ) TT");
			strSql.AppendFormat(" WHERE TT.Row between {0} and {1}", startIndex, endIndex);
			return DbHelperSQL.Query(strSql.ToString());
		}

		/*
		/// <summary>
		/// 分页获取数据列表
		/// </summary>
		public DataSet GetList(int PageSize,int PageIndex,string strWhere)
		{
			SqlParameter[] parameters = {
					new SqlParameter("@SQL2012tblName", SqlDbType.VarChar, 255),
					new SqlParameter("@SQL2012fldName", SqlDbType.VarChar, 255),
					new SqlParameter("@SQL2012PageSize", SqlDbType.Int),
					new SqlParameter("@SQL2012PageIndex", SqlDbType.Int),
					new SqlParameter("@SQL2012IsReCount", SqlDbType.Bit),
					new SqlParameter("@SQL2012OrderType", SqlDbType.Bit),
					new SqlParameter("@SQL2012strWhere", SqlDbType.VarChar,1000),
					};
			parameters[0].Value = "Scoure";
			parameters[1].Value = "c_number";
			parameters[2].Value = PageSize;
			parameters[3].Value = PageIndex;
			parameters[4].Value = 0;
			parameters[5].Value = 0;
			parameters[6].Value = strWhere;	
			return DbHelperSQL.RunProcedure("UP_GetRecordByPage",parameters,"ds");
		}*/

		#endregion  BasicMethod
		#region  ExtensionMethod

		#endregion  ExtensionMethod
	}
}

