﻿using System;
namespace hua_elective.Model
{
	/// <summary>
	/// CourseModel:实体类(属性说明自动提取数据库字段的描述信息)
	/// </summary>
	[Serializable]
	public partial class CourseModel
	{
		public CourseModel()
		{}
		#region Model
		private int _c_number;
		private string _c_name;
		/// <summary>
		/// 
		/// </summary>
		public int c_number
		{
			set{ _c_number=value;}
			get{return _c_number;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string c_name
		{
			set{ _c_name=value;}
			get{return _c_name;}
		}
		#endregion Model

	}
}

