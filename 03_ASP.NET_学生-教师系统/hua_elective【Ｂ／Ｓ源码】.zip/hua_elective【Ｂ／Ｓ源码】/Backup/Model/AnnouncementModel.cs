﻿using System;
namespace hua_elective.Model
{
	/// <summary>
	/// AnnouncementModel:实体类(属性说明自动提取数据库字段的描述信息)
	/// </summary>
	[Serializable]
	public partial class AnnouncementModel
	{
		public AnnouncementModel()
		{}
		#region Model
		private int _a_number;
		private string _a_content;
		/// <summary>
		/// 
		/// </summary>
		public int a_number
		{
			set{ _a_number=value;}
			get{return _a_number;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string a_content
		{
			set{ _a_content=value;}
			get{return _a_content;}
		}
		#endregion Model

	}
}

