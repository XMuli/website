﻿using System;
namespace hua_elective.Model
{
	/// <summary>
	/// StudentModel:实体类(属性说明自动提取数据库字段的描述信息)
	/// </summary>
	[Serializable]
	public partial class StudentModel
	{
		public StudentModel()
		{}
		#region Model
		private int _s_number;
		private string _s_user_name;
		private string _s_user_password;
		private string _s_name;
		private string _s_age;
		private string _s_sex;
		/// <summary>
		/// 
		/// </summary>
		public int s_number
		{
			set{ _s_number=value;}
			get{return _s_number;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string s_user_name
		{
			set{ _s_user_name=value;}
			get{return _s_user_name;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string s_user_password
		{
			set{ _s_user_password=value;}
			get{return _s_user_password;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string s_name
		{
			set{ _s_name=value;}
			get{return _s_name;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string s_age
		{
			set{ _s_age=value;}
			get{return _s_age;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string s_sex
		{
			set{ _s_sex=value;}
			get{return _s_sex;}
		}
		#endregion Model

	}
}

