﻿using System;
namespace hua_elective.Model
{
	/// <summary>
	/// TeacherModel:实体类(属性说明自动提取数据库字段的描述信息)
	/// </summary>
	[Serializable]
	public partial class TeacherModel
	{
		public TeacherModel()
		{}
		#region Model
		private int _t_number;
		private string _t_user_name;
		private string _t_user_password;
		private string _t_name;
		private string _t_age;
		private string _t_sex;
		/// <summary>
		/// 
		/// </summary>
		public int t_number
		{
			set{ _t_number=value;}
			get{return _t_number;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string t_user_name
		{
			set{ _t_user_name=value;}
			get{return _t_user_name;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string t_user_password
		{
			set{ _t_user_password=value;}
			get{return _t_user_password;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string t_name
		{
			set{ _t_name=value;}
			get{return _t_name;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string t_age
		{
			set{ _t_age=value;}
			get{return _t_age;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string t_sex
		{
			set{ _t_sex=value;}
			get{return _t_sex;}
		}
		#endregion Model

	}
}

