﻿using System;
namespace hua_elective.Model
{
	/// <summary>
	/// ScoureModel:实体类(属性说明自动提取数据库字段的描述信息)
	/// </summary>
	[Serializable]
	public partial class ScoureModel
	{
		public ScoureModel()
		{}
		#region Model
		private int _s_number;
		private int _c_number;
		private int? _sc_scoure;
		private string _sc_check;
		/// <summary>
		/// 
		/// </summary>
		public int s_number
		{
			set{ _s_number=value;}
			get{return _s_number;}
		}
		/// <summary>
		/// 
		/// </summary>
		public int c_number
		{
			set{ _c_number=value;}
			get{return _c_number;}
		}
		/// <summary>
		/// 
		/// </summary>
		public int? sc_scoure
		{
			set{ _sc_scoure=value;}
			get{return _sc_scoure;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string sc_check
		{
			set{ _sc_check=value;}
			get{return _sc_check;}
		}
		#endregion Model

	}
}

